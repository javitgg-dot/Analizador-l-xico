/* A Bison parser, made by GNU Bison 2.4.2.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2006, 2009-2010 Free Software
   Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INTEGER = 258,
     DOUBLE = 259,
     FLOAT = 260,
     DATETIME = 261,
     STRING = 262,
     URL = 263,
     INI_ORDENCOMPRA = 264,
     INI_FIRMA = 265,
     FIN_FIRMA = 266,
     FIN_ORDENCOMPRA = 267,
     INI_FECHAPEDIDO = 268,
     FIN_FECHAPEDIDO = 269,
     INI_NUMEROORDEN = 270,
     FIN_NUMEROORDEN = 271,
     INI_ORGANIZACION = 272,
     FIN_ORGANIZACION = 273,
     INI_NOMBREORG = 274,
     FIN_NOMBREORG = 275,
     INI_CODIGOORG = 276,
     FIN_CODIGOORG = 277,
     INI_PETICIONARIO = 278,
     FIN_PETICIONARIO = 279,
     INI_NOMBRE = 280,
     FIN_NOMBRE = 281,
     INI_APELLIDOS = 282,
     FIN_APELLIDOS = 283,
     INI_EMPLEO = 284,
     FIN_EMPLEO = 285,
     INI_EXTENSION = 286,
     FIN_EXTENSION = 287,
     INI_EMAIL = 288,
     FIN_EMAIL = 289,
     INI_DIRECCIONENVIO = 290,
     FIN_DIRECCIONENVIO = 291,
     INI_NOMBREPETICIONARIO = 292,
     FIN_NOMBREPETICIONARIO = 293,
     INI_CALLEPET = 294,
     FIN_CALLEPET = 295,
     INI_NUMPET = 296,
     FIN_NUMPET = 297,
     INI_CIUDADPET = 298,
     FIN_CIUDADPET = 299,
     INI_CP = 300,
     FIN_CP = 301,
     INI_PAIS = 302,
     FIN_PAIS = 303,
     INI_DIRECCIONFACTURACION = 304,
     FIN_DIRECCIONFACTURACION = 305,
     INI_NOMBREFACTURA = 306,
     FIN_NOMBREFACTURA = 307,
     INI_CALLEFACTURA = 308,
     FIN_CALLEFACTURA = 309,
     INI_NUMEROFAC = 310,
     FIN_NUMEROFAC = 311,
     INI_CIUDADFAC = 312,
     FIN_CIUDADFAC = 313,
     INI_COSTETOTAL = 314,
     FIN_COSTETOTAL = 315,
     INI_COMPONENTES = 316,
     FIN_COMPONENTES = 317,
     INI_NUMEROCOMPONENTES = 318,
     FIN_NUMEROCOMPONENTES = 319,
     INI_COMPONENTE = 320,
     FIN_COMPONENTE = 321,
     INI_CODIGOCOMP = 322,
     FIN_CODIGOCOMP = 323,
     INI_NOMBREPROD = 324,
     FIN_NOMBREPROD = 325,
     INI_CANTIDAD = 326,
     FIN_CANTIDAD = 327,
     INI_PRECIOUNIDAD = 328,
     FIN_PRECIOUNIDAD = 329,
     INI_PRECIOCOMP = 330,
     FIN_PRECIOCOMP = 331,
     INI_TAMANOCOMPONENTE = 332,
     FIN_TAMANOCOMPONENTE = 333,
     INI_TAMANOMENSAJE = 334,
     FIN_TAMANOMENSAJE = 335
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1685 of yacc.c  */
#line 33 "analizador.y"
 
       int    entero; 
       double real; 
       char* texto; 
        


/* Line 1685 of yacc.c  */
#line 139 "analizador.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


